import DashboardHeader from "../../../components/DashboardHeader";
import DashboardSidebar from "../../../components/DashboardSidebar";
import CatalogueDrop from "../../../components/dashboard-produits/CatalogueDrop";

/*
  Écran 05 "Catalogue disponible en drop", atteint depuis le bouton "Voir
  les produits disponibles en drop" (Écran 04, voir PartenaireAgree.tsx) ou
  "Retour" de la fiche produit (Écran 06, voir FicheProduitDrop.tsx) — page
  à part, plus un onglet de l'onglet "Produits" (même mouvement que
  Partenaire agréé, cf. app/dashboard/partenaire-agree/page.tsx).
*/
export default function CatalogueDropPage() {
  return (
    <div className="min-h-screen w-full bg-[var(--dashboard-bg)] font-sans text-[var(--dashboard-text)] antialiased transition-colors">
      <div className="mx-auto flex max-w-[1620px] flex-col gap-6 px-4 pb-28 pt-6 sm:px-6 md:px-10 lg:flex-row lg:pb-10 lg:pl-3 lg:pt-8">
        <DashboardSidebar />

        <div className="min-w-0 flex-1 lg:px-6">
          <DashboardHeader activeAccueilTab="Produits" />
          <CatalogueDrop />
        </div>
      </div>
    </div>
  );
}
