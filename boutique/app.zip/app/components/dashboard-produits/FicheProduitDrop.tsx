"use client";

import Link from "next/link";
import { useState } from "react";
import { Card, ProduitCarousel, Tag, texteAvecChiffres } from "../dashboard-accueil/shared";
import type { DropProduit } from "./dropCatalogue";
import { getCategoryLabelEn } from "./dropCatalogue";
import { useDashboardLangue } from "../DashboardLanguageProvider";

/*
  Écran 06 "La fiche d'un produit drop" : les quatre prix (le vôtre, moyen,
  bas, haut du réseau), la description, et un simulateur qui recalcule ce
  qu'il vous reste selon le prix de vente que vous fixez. Reçoit le produit
  déjà résolu (voir app/dashboard/produits/catalogue/[slug]/page.tsx) plutôt
  que de refaire la recherche ici. Atteint depuis une tuile du catalogue
  (Écran 05, CatalogueDrop.tsx) — le bouton "Voir la fiche" de l'aperçu en
  avant mène, lui, à l'aperçu plus léger (ApercuProduitDrop.tsx).
*/

// Barème logistique du partenaire (voir Écran 04) : mêmes 1 500 F de frais
// fixes ; la commission suit le taux du réseau (~4 % du prix de vente fixé).
const FRAIS_LOGISTIQUES = 1500;
const TAUX_COMMISSION = 0.04;

export default function FicheProduitDrop({ produit }: { produit: DropProduit }) {
  const { t, langue } = useDashboardLangue();
  const F = (n: number) => `${Math.round(n).toLocaleString(langue === "EN" ? "en-US" : "fr-FR")} F`;
  const [monPrix, setMonPrix] = useState(produit.prixVenteActuel ?? produit.prixConseille ?? produit.prixDrop ?? 0);

  const [produitChoisi, setProduitChoisi] = useState(false);
  const [misDeCote, setMisDeCote] = useState(false);
  const commission = Math.round(monPrix * TAUX_COMMISSION);
  const ilReste = monPrix - (produit.prixDrop ?? 0) - FRAIS_LOGISTIQUES - commission;

  const scalePct =
    produit.prixBasReseau && produit.prixHautReseau
      ? Math.min(100, Math.max(0, ((monPrix - produit.prixBasReseau) / (produit.prixHautReseau - produit.prixBasReseau)) * 100))
      : 50;

  const categorieLabel = t(produit.categorie, getCategoryLabelEn(produit.categorie));
  const conditionnementLabel = produit.conditionnement ? t(produit.conditionnement, produit.conditionnementEn ?? produit.conditionnement) : undefined;

  return (
    <>
      <Link
        href="/dashboard/produits/catalogue"
        className="mt-5 inline-flex items-center gap-1.5 rounded-full border border-[var(--dashboard-text)]/15 bg-[var(--dashboard-card-bg)]/60 px-3.5 py-2 text-xs font-semibold"
      >
        <svg viewBox="0 0 24 24" fill="none" className="h-3 w-3">
          <path d="m14.5 5-7 7 7 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
        {categorieLabel}
      </Link>

      {/* ── Galerie + infos côte à côte ── */}
      <div className="mt-4 grid items-start gap-8" style={{ gridTemplateColumns: 'minmax(0, 1fr) 340px' }}>

        {/* Galerie (colonne gauche) */}
        <div className="min-w-0">
          <ProduitCarousel images={produit.images ?? []} videoUrl={produit.videoUrl} />
        </div>

        {/* Infos produit (colonne droite) */}
        <div>
          <div className="flex flex-wrap items-center gap-1.5">
            <Tag tone="pink">{produit.source === "L" ? t("Drop LM", "LM drop") : t("Partenaire", "Partner")}</Tag>
            {produit.unitesDisponibles !== undefined && (
              <Tag tone="neutral">
                <span>{t("Disponible", "Available")} · {texteAvecChiffres(t(`${produit.unitesDisponibles} unités`, `${produit.unitesDisponibles} units`))}</span>
              </Tag>
            )}
            <Tag tone="neutral">{t("Réf.", "Ref.")} {produit.slug.slice(0, 8).toUpperCase()}</Tag>
          </div>
          <p className="mt-3 text-2xl font-semibold tracking-tight">{texteAvecChiffres(t(produit.nom, produit.nomEn ?? produit.nom))}</p>
          <p className="mt-1 text-xs text-[var(--dashboard-text)]/50">
            {texteAvecChiffres([categorieLabel, conditionnementLabel, produit.contenance].filter(Boolean).join(" · "))}
          </p>
        </div>
      </div>

      <div className="mt-4 grid items-start gap-3 lg:grid-cols-[1.1fr_1.25fr_0.95fr] [&>*]:min-w-0">
        <Card title={t("Les quatre prix", "The four prices")} titleTab className="!bg-[var(--dashboard-card-bg)]">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <p className="text-[10px] uppercase tracking-[0.16em] text-[var(--dashboard-text)]/40">{t("Vous payez ce produit", "You pay for this product")}</p>
            <Tag tone="dark">{t("Sur ce partenaire", "From this partner")}</Tag>
          </div>
          <div className="mt-1.5 flex items-center justify-between gap-2">
            <p className="-ml-4 inline-block rounded-r-xl bg-brand-purple py-2 pl-4 pr-4 text-2xl tracking-tight text-white font-figures-bold">
              {F(produit.prixDrop ?? 0)}
            </p>
            <Tag tone="neutral">{t("Prix drop", "Drop price")}</Tag>
          </div>
          <div className="my-3 h-px bg-[var(--dashboard-text)]/10" />
          <div className="flex items-center justify-between text-xs">
            <span className="text-[var(--dashboard-text)]/50">{t("Prix moyen de revente", "Average resale price")}</span>
            <span className="font-figures-bold">{produit.prixMoyenReseau ? F(produit.prixMoyenReseau) : "—"}</span>
          </div>
          <div className="mt-2 flex items-center justify-between text-xs">
            <span className="text-[var(--dashboard-text)]/50">{t("Le plus bas pratiqué", "Lowest seen")}</span>
            <span className="font-figures-bold">{produit.prixBasReseau ? F(produit.prixBasReseau) : "—"}</span>
          </div>
          <div className="mt-2 flex items-center justify-between text-xs">
            <span className="text-[var(--dashboard-text)]/50">{t("Le plus haut pratiqué", "Highest seen")}</span>
            <span className="font-figures-bold">{produit.prixHautReseau ? F(produit.prixHautReseau) : "—"}</span>
          </div>
          {produit.prixBasReseau && produit.prixHautReseau && (
            <>
              <div className="relative mt-3 h-1 rounded-full bg-[linear-gradient(90deg,#C9CFDD,#EC0C8C)]">
                <span
                  className="absolute -top-1.5 h-4 w-0.5 rounded-full bg-[#141220] shadow-[0_0_0_2px_#fff]"
                  style={{ left: `${scalePct}%` }}
                />
              </div>
              <div className="mt-1.5 flex justify-between text-[9px] text-[var(--dashboard-text)]/40">
                <span className="font-figures">{F(produit.prixBasReseau)}</span>
                <span className="font-semibold text-[var(--dashboard-text)]">{t("Vous", "You")} : {texteAvecChiffres(F(monPrix))}</span>
                <span className="font-figures">{F(produit.prixHautReseau)}</span>
              </div>
            </>
          )}
        </Card>

        <Card title={t("Description", "Description")} titleTab className="!bg-[var(--dashboard-card-bg)]">
          <p className="mt-2.5 text-xs text-[var(--dashboard-text)]/70">{produit.description ? t(produit.description, produit.descriptionEn ?? produit.description) : "—"}</p>
          <div className="my-3 h-px bg-[var(--dashboard-text)]/10" />
          {produit.conditionnement && <Row label={t("Conditionnement", "Packaging")} value={texteAvecChiffres(conditionnementLabel!)} />}
          {produit.contenance && <Row label={t("Contenance", "Volume")} value={texteAvecChiffres(produit.contenance)} />}
          {produit.poidsEmballe && <Row label={t("Poids emballé", "Packaged weight")} value={texteAvecChiffres(produit.poidsEmballe)} />}
          {produit.venduParBoutiques !== undefined && <Row label={t("Vendu par", "Sold by")} value={texteAvecChiffres(t(`${produit.venduParBoutiques} boutiques du réseau`, `${produit.venduParBoutiques} shops in the network`))} />}
          {produit.ventesReseau30j !== undefined && <Row label={texteAvecChiffres(t("Ventes du réseau · 30 j", "Network sales · 30 days"))} value={texteAvecChiffres(String(produit.ventesReseau30j))} />}
          {produit.vosVentes30j !== undefined && <Row label={texteAvecChiffres(t("Vos ventes · 30 j", "Your sales · 30 days"))} value={texteAvecChiffres(String(produit.vosVentes30j))} />}
          {produit.tauxLitigePct !== undefined && <Row label={t("Taux de litige", "Dispute rate")} value={texteAvecChiffres(`${produit.tauxLitigePct} %`)} />}
        </Card>

        <div>
          <div className="rounded-2xl bg-[linear-gradient(155deg,#3B1FA8_0%,#1B1E72_46%,#0A0E28_100%)] p-4 text-white">
            <p className="text-[10px] uppercase tracking-[0.16em] text-white/60">{t("Fixer mon prix", "Set my price")}</p>
            <div className="mt-2.5 rounded-2xl border border-white/25 bg-white/10 px-3.5 py-2.5">
              <p className="text-[10px] text-white/60">{t("Mon prix de vente", "My sale price")}</p>
              <input
                type="number"
                value={monPrix}
                onChange={(e) => setMonPrix(Number(e.target.value) || 0)}
                className="w-full bg-transparent text-lg tabular-nums outline-none font-figures-bold"
              />
            </div>
            <div className="mt-3 flex items-center justify-between text-xs text-white/55">
              <span>− {t("Prix du produit", "Product price")}</span>
              <span className="font-figures text-white/80">{F(produit.prixDrop ?? 0)}</span>
            </div>
            <div className="mt-1.5 flex items-center justify-between text-xs text-white/55">
              <span>− {t("Frais logistiques", "Logistics fees")}</span>
              <span className="font-figures text-white/80">{F(FRAIS_LOGISTIQUES)}</span>
            </div>
            <div className="mt-1.5 flex items-center justify-between text-xs text-white/55">
              <span>− {t("Commission et paiement", "Commission & payment")}</span>
              <span className="font-figures text-white/80">{F(commission)}</span>
            </div>
            <div className="my-3 h-px bg-white/15" />
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold">{t("Il vous reste", "You're left with")}</span>
              <span className={`text-lg font-figures-bold ${ilReste < 0 ? "text-red-300" : "text-brand-pink"}`}>{F(ilReste)}</span>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setProduitChoisi(true)}
            disabled={produitChoisi}
            aria-pressed={produitChoisi}
            className={`mt-3 w-full rounded-full px-4 py-2.5 text-center text-xs font-semibold shadow-[0_2px_10px_rgba(20,18,32,0.08)] transition ${
              produitChoisi ? "bg-brand-pink text-white" : "bg-[var(--dashboard-card-bg)] hover:brightness-95"
            }`}
          >
            {produitChoisi ? t("Produit choisi", "Product chosen") : t("Choisir le produit", "Choose this product")}
          </button>
          <button
            type="button"
            onClick={() => setMisDeCote(true)}
            disabled={misDeCote}
            aria-pressed={misDeCote}
            className={`mt-2 w-full rounded-full px-4 py-2.5 text-center text-xs font-semibold text-white transition ${
              misDeCote ? "bg-[#141220]/60 dark:bg-brand-pink/60" : "bg-[#141220] dark:bg-brand-pink hover:brightness-95"
            }`}
          >
            {misDeCote ? t("Mis de côté", "Saved for later") : t("Mettre de côté", "Set aside")}
          </button>
        </div>
      </div>
    </>
  );
}

function Row({ label, value }: { label: React.ReactNode; value: React.ReactNode }) {
  return (
    <div className="mt-2 flex items-center justify-between text-xs">
      <span className="text-[var(--dashboard-text)]/50">{label}</span>
      <span>{value}</span>
    </div>
  );
}
