import ScrollReveal from "../ScrollReveal";
import VisionEyebrow from "./VisionEyebrow";

// Section 3/4 de la page "/vision" : "Ce que l'infrastructure produit",
// 3 colonnes séparées par une fine ligne horizontale au-dessus de chaque
// titre (voir la capture fournie par l'utilisateur).
const COLUMNS = [
  {
    title: "Volume",
    body: "Le portefeuille de l'opérateur s'élargit à mesure que le réseau s'étend sur son territoire.",
  },
  {
    title: "Exécution",
    body: "Commandes, stocks et tournées restent synchronisés dans un système unique.",
  },
  {
    title: "Règlement",
    body: "Les fonds sont tracés du paiement de l'acheteur jusqu'au reversement à l'opérateur.",
  },
];

export default function VisionEffects() {
  return (
    <section className="bg-brand-bg px-6 py-24 md:px-16">
      <div className="mx-auto max-w-[1320px]">
        <ScrollReveal>
          <VisionEyebrow>Les effets</VisionEyebrow>
          <h2 className="mt-4 max-w-md text-3xl font-semibold leading-tight sm:text-4xl">
            Ce que l&apos;infrastructure produit
          </h2>
        </ScrollReveal>

        {/* Colonnes révélées en cascade (100ms de décalage entre chacune)
            plutôt que toutes en même temps que le titre. */}
        <div className="mt-20 grid gap-10 sm:grid-cols-3">
          {COLUMNS.map((col, i) => (
            <ScrollReveal
              key={col.title}
              delay={i * 100}
              className="border-t border-white/15 pt-6"
            >
              <h3 className="text-xl font-medium">{col.title}</h3>
              <p className="mt-4 text-brand-white/70">{col.body}</p>
            </ScrollReveal>
          ))}
        </div>
      </div>
    </section>
  );
}
